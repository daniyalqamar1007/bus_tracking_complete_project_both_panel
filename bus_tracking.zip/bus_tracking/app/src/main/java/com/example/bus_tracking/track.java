package com.example.bus_tracking;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class track extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track);
    }
}